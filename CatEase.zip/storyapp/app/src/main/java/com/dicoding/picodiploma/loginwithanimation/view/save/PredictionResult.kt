package com.dicoding.picodiploma.loginwithanimation.view.save

data class PredictionResult(
    val predictedLabel: String,
    val articleTitle: String,
    val articleContent: String,
    val imagePath: String
)