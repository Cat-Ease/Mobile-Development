package com.dicoding.picodiploma.loginwithanimation.view.article

data class Article(
    val id: String,
    val title: String,
    val description: String,
    val image: String
)